# Native POS Windows Release
**Version:** 1.0.0+14
**Stage:** prod
**Platform:** Windows x64

## Installation
1. Download ShopAndSmilePOS-Setup-1.0.0+14-prod.exe
2. Run the installer
3. Follow the setup wizard

## Requirements
- Windows 10 or later (64-bit)
