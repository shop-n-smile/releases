# Native POS Android Release
**Version:** 1.0.0+13
**Stage:** test
**Platform:** Android

## Installation
1. Download ShopAndSmilePOS.apk
2. Enable "Install from unknown sources" if needed
3. Install the APK on your Android device
